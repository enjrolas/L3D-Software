#include "neopixel/neopixel.h"
#include "datatypes.h"
#include <math.h>
#include "cube.h"

void zPlasma(Adafruit_NeoPixel& strip);
